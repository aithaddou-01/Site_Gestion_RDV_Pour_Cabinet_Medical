import React from 'react';
import './index.css';
import Patient1Image from '../../../images/img/Halima.jpg';
import Patient2Image from '../../../images/img/Mbarek.jpeg';
import Patient3Image from '../../../images/img/Hatim.jpeg';
import Patient4Image from '../../../images/img/Fatima.jpeg';
import Patient5Image from '../../../images/img/Jamal.jpg';
import Patient6Image from '../../../images/img/Jasmine.jpg';
import StarRatings from 'react-star-ratings';
import { truncate } from '../../../utils/truncate';
import { FaCheckDouble } from "react-icons/fa";
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Autoplay, Pagination, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/autoplay';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

const patientsData = [
  {
    name: 'Halima Benani',
    image: Patient1Image,
    testimonial: 'Le Dr. Hafid est un médecin exceptionnel. Il est à l\'écoute, compétent et très professionnel. Je me sens toujours en confiance lorsque je le consulte.'
  },
  {
    name: 'Ait Haddou Mbarek',
    image: Patient2Image,
    testimonial: 'J\'ai été très impressionnée par le Dr. Ortügrul. Elle est douce, patiente et explique clairement les traitements. Je recommande vivement ses services.'
  },
  {
    name: 'Drighil Hatim',
    image: Patient3Image,
    testimonial: 'Le Dr. Hafid m\'a aidée à comprendre mon problème de santé avec patience et compassion. Un médecin formidable.'
  },
  {
    name: 'Fatima Zahrae Reddisse',
    image: Patient4Image,
    testimonial: 'Le Dr. Ortügrul est très attentionnée et professionnelle. Ses conseils m\'ont beaucoup aidé à améliorer ma santé.'
  },
  {
    name: 'Jamal Benomar',
    image: Patient5Image,
    testimonial: 'Je suis très satisfaite des soins fournis par le Dr. Hafid. Toujours à l\'écoute et efficace.'
  },
  {
    name: 'Jasmine Lakhdar',
    image: Patient6Image,
    testimonial: 'Le Dr. Ortügrul est un excellent médecin. Très compétente et toujours prête à répondre à mes questions.'
  }
];

const Testimonial = () => {
  return (
    <div className="container" style={{ marginTop: "10rem", marginBottom: "10rem" }}>
      <div className='mb-5 section-title text-center'>
        <h2>TÉMOIGNAGE</h2>
        <p className='m-0 text-secondary'>Ce que disent nos patients</p>
      </div>
      <div className="row d-flex justify-content-center">
        <Swiper
          spaceBetween={30}
          slidesPerView={1}
          slidesPerGroup={1}
          modules={[Navigation, Autoplay, Pagination, EffectFade]}
          navigation
          loop
          centeredSlides
          autoplay={{ delay: 2500, disableOnInteraction: false }}
          pagination={{ clickable: true }}
          effect='fade'
        >
          {patientsData.map((item, key) => (
            <SwiperSlide key={key}>
              <div className="card shadow p-3 border-0 my-5 mx-auto" style={{ maxWidth: '600px' }}>
                <div className='d-flex gap-2'>
                  <div className='review-img'>
                    {item.image && <img src={item.image} alt={item.name} className='shadow' />}
                  </div>
                  <div>
                    <h5 className='text-secondary'>{item.name}</h5>
                  </div>
                </div>
                <p className="text-start text-secondary" style={{ minHeight: '72px', overflow: 'hidden' }}>{truncate(item.testimonial, 150)}</p>
                <div>
                  <p className='recomended'><FaCheckDouble /> Recommandé</p>
                  <StarRatings
                    rating={5}
                    starRatedColor="#f4c150"
                    numberOfStars={5}
                    name='rating'
                    className="star"
                    starDimension="20px"
                    starSpacing="5px"
                  />
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default Testimonial;
