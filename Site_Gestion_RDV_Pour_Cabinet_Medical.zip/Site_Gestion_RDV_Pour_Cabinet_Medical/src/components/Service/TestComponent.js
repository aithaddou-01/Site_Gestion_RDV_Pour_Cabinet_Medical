import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getTestData } from '../../redux/feature/testSlice';

function TestComponent() {
    const dispatch = useDispatch();
    const { data, loading, error } = useSelector((state) => state.test);

    useEffect(() => {
        dispatch(getTestData());
    }, [dispatch]);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    return (
        <div>
            <h1>{data ? data.message : 'No data'}</h1>
        </div>
    );
}

export default TestComponent;
