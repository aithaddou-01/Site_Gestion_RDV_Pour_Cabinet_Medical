import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

export const fetchTestData = () => {
    return axios.get(`${API_URL}/test`)
        .then(response => response.data)
        .catch(error => {
            console.error('There was an error fetching the data!', error);
        });
};
