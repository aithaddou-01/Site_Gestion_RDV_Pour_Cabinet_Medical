import { Popover } from "antd";
import { Link, NavLink } from "react-router-dom";
import { FaBars } from "react-icons/fa";
import { Drawer, Button } from "antd";
import {
    FaHome,
    FaPhoneAlt,
    FaWrench,
    FaAddressBook,
    FaBloggerB,
    FaSignInAlt,
} from "react-icons/fa";

const HeaderNav = ({ open, setOpen, isLoggedIn, data, avatar, content }) => {
    const showDrawer = () => {
        setOpen(true);
    };
    const onClose = () => {
        setOpen(false);
    };

    return (
        <>
            <nav id="navbar" className="navbar order-last order-lg-0">
                <ul>
                    <li>
                        <NavLink
                            to={"/"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            Accueil
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/about"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            A propos
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/service"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            Service
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/contact"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            Contact
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/blog"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            Blog
                        </NavLink>
                    </li>
                    {!isLoggedIn && (
                        <li>
                            <Link to={"/login"} className="nav-link scrollto">
                                Connexion
                            </Link>
                        </li>
                    )}
                </ul>
                {isLoggedIn && (
                    <div>
                        <Popover content={content}>
                            <div className="profileImage">
                                <img
                                    src={data?.img ? data?.img : avatar}
                                    alt=""
                                    className="profileImage shadow img-fluid"
                                />
                            </div>
                        </Popover>
                    </div>
                )}
                <FaBars className="mobile-nav-toggle" onClick={showDrawer} />
            </nav>
            <Drawer
                placement={"left"}
                width={300}
                onClose={onClose}
                open={open}
                size={"default"}
                extra={
                    <Button type="primary" onClick={onClose}>
                        {" "}
                        Fermer
                    </Button>
                }
            >
                <ul className="mobile-menu-nav">
                    <li>
                        <NavLink
                            to={"/"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            <FaHome className="icon" />
                            Accueil
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/about"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            <FaAddressBook className="icon" />A propos
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/service"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            <FaWrench className="icon" />
                            Service
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/contact"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            <FaPhoneAlt className="icon" />
                            Contact
                        </NavLink>
                    </li>
                    <li>
                        <NavLink
                            to={"/blog"}
                            className={({ isActive }) =>
                                isActive ? "nav-link scrollto active" : ""
                            }
                        >
                            <FaBloggerB className="icon" />
                            Blog
                        </NavLink>
                    </li>
                    {!isLoggedIn && (
                        <li>
                            <Link to={"/login"} className="nav-link scrollto">
                                <FaSignInAlt className="icon" />
                                Connexion
                            </Link>
                        </li>
                    )}
                </ul>
            </Drawer>
        </>
    );
};

export default HeaderNav;
