#!/bin/bash
node start