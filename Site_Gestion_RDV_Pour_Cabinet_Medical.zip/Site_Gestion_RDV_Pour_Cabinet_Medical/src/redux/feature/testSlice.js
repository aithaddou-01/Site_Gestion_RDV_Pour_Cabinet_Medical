import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { fetchTestData } from '../api/testApi';

export const getTestData = createAsyncThunk('test/getTestData', async () => {
    const response = await fetchTestData();
    return response;
});

const testSlice = createSlice({
    name: 'test',
    initialState: {
        data: null,
        loading: false,
        error: null,
    },
    extraReducers: {
        [getTestData.pending]: (state) => {
            state.loading = true;
        },
        [getTestData.fulfilled]: (state, action) => {
            state.loading = false;
            state.data = action.payload;
        },
        [getTestData.rejected]: (state, action) => {
            state.loading = false;
            state.error = action.error.message;
        },
    },
});

export default testSlice.reducer;
